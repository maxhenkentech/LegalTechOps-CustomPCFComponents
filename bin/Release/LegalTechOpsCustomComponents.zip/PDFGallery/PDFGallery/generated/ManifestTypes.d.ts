/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    fileColumnName: ComponentFramework.PropertyTypes.StringProperty;
    tabLabelColumnName: ComponentFramework.PropertyTypes.StringProperty;
    allowDownload: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    showButtonLabels: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    tabLabelMaxChars: ComponentFramework.PropertyTypes.WholeNumberProperty;
    allowOpenRecord: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    style: ComponentFramework.PropertyTypes.EnumProperty<"Horizontal" | "Vertical">;
    documents: ComponentFramework.PropertyTypes.DataSet;
}
export interface IOutputs {
}
