/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    parentLookup: ComponentFramework.PropertyTypes.LookupProperty;
    showState: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    showInactiveRecords: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    maxParentLevels: ComponentFramework.PropertyTypes.WholeNumberProperty;
    maxChildLevels: ComponentFramework.PropertyTypes.WholeNumberProperty;
    siblingDisplay: ComponentFramework.PropertyTypes.EnumProperty<"None" | "DirectOnly" | "SistersAndChildren">;
    sortByColumnName: ComponentFramework.PropertyTypes.StringProperty;
    sortDirection: ComponentFramework.PropertyTypes.EnumProperty<"Ascending" | "Descending">;
    currentRecordHighlightColor: ComponentFramework.PropertyTypes.StringProperty;
    customAttribute1: ComponentFramework.PropertyTypes.StringProperty;
    customAttribute2: ComponentFramework.PropertyTypes.StringProperty;
    customAttribute3: ComponentFramework.PropertyTypes.StringProperty;
    thumbnailColumnName: ComponentFramework.PropertyTypes.StringProperty;
    thumbnailStyle: ComponentFramework.PropertyTypes.EnumProperty<"Circle" | "Square" | "RoundedSquare">;
    thumbnailIconColorMode: ComponentFramework.PropertyTypes.EnumProperty<"Default" | "ChoiceColorForIcon" | "ChoiceColorForBackground" | "FixedSolid" | "FixedLight">;
    thumbnailRenderingOption: ComponentFramework.PropertyTypes.EnumProperty<"Cover" | "Stretch" | "Contain" | "Center" | "Tile" | "FitWidth" | "FitHeight">;
    quickViewFormName: ComponentFramework.PropertyTypes.StringProperty;
    choiceColorDisplay: ComponentFramework.PropertyTypes.EnumProperty<"None" | "Circle" | "Pill" | "Font">;
    indentation: ComponentFramework.PropertyTypes.EnumProperty<"Low" | "Medium" | "High">;
}
export interface IOutputs {
    parentLookup?: ComponentFramework.LookupValue[];
}
