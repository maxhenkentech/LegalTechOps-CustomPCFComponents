/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    optionsInput: ComponentFramework.PropertyTypes.OptionSetProperty;
    icon: ComponentFramework.PropertyTypes.StringProperty;
    useExternalValueForIcon: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    hideHiddenOptions: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    sortBy: ComponentFramework.PropertyTypes.EnumProperty<"Value" | "Text">;
    tileShape: ComponentFramework.PropertyTypes.EnumProperty<"Square" | "Rounded">;
    tileSize: ComponentFramework.PropertyTypes.EnumProperty<"Small" | "Normal" | "Large">;
    showChoiceValue: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    makeFontBold: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    notSelectedColor: ComponentFramework.PropertyTypes.StringProperty;
    hoverColor: ComponentFramework.PropertyTypes.StringProperty;
    selectedBackgroundMode: ComponentFramework.PropertyTypes.EnumProperty<"CustomColor" | "ChoiceColor" | "CustomColorFaded">;
    selectedColor: ComponentFramework.PropertyTypes.StringProperty;
    selectedBorderMode: ComponentFramework.PropertyTypes.EnumProperty<"Off" | "CustomColor" | "ChoiceColor" | "CustomColorFaded">;
    selectedBorderColor: ComponentFramework.PropertyTypes.StringProperty;
    iconColorMode: ComponentFramework.PropertyTypes.EnumProperty<"Auto" | "CustomColor" | "ChoiceColor" | "CustomColorFaded">;
    iconColor: ComponentFramework.PropertyTypes.StringProperty;
    iconColorScope: ComponentFramework.PropertyTypes.EnumProperty<"AllTiles" | "SelectedOnly">;
}
export interface IOutputs {
    optionsInput?: number;
}
