/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    boundField: ComponentFramework.PropertyTypes.Property;
    saveOnClick: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    tileShape: ComponentFramework.PropertyTypes.EnumProperty<"Square" | "Rounded">;
    tileSize: ComponentFramework.PropertyTypes.EnumProperty<"Small" | "Normal" | "Large">;
    showLabel: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    iconPosition: ComponentFramework.PropertyTypes.EnumProperty<"Above" | "Below" | "Left" | "Right">;
    reflowBehaviour: ComponentFramework.PropertyTypes.EnumProperty<"Wrap" | "Flexible">;
    makeFontBold: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    backgroundMode: ComponentFramework.PropertyTypes.EnumProperty<"Fixed" | "PerButtonColor">;
    buttonColor: ComponentFramework.PropertyTypes.StringProperty;
    hoverColor: ComponentFramework.PropertyTypes.StringProperty;
    activeColor: ComponentFramework.PropertyTypes.StringProperty;
    borderMode: ComponentFramework.PropertyTypes.EnumProperty<"Off" | "Fixed" | "PerButtonColor">;
    borderColor: ComponentFramework.PropertyTypes.StringProperty;
    iconColorMode: ComponentFramework.PropertyTypes.EnumProperty<"Auto" | "Fixed" | "PerButtonColor">;
    iconColor: ComponentFramework.PropertyTypes.StringProperty;
    button1Label: ComponentFramework.PropertyTypes.StringProperty;
    button1Icon: ComponentFramework.PropertyTypes.StringProperty;
    button1Color: ComponentFramework.PropertyTypes.StringProperty;
    button1Tooltip: ComponentFramework.PropertyTypes.StringProperty;
    button1Actions: ComponentFramework.PropertyTypes.StringProperty;
    button2Label: ComponentFramework.PropertyTypes.StringProperty;
    button2Icon: ComponentFramework.PropertyTypes.StringProperty;
    button2Color: ComponentFramework.PropertyTypes.StringProperty;
    button2Tooltip: ComponentFramework.PropertyTypes.StringProperty;
    button2Actions: ComponentFramework.PropertyTypes.StringProperty;
    button3Label: ComponentFramework.PropertyTypes.StringProperty;
    button3Icon: ComponentFramework.PropertyTypes.StringProperty;
    button3Color: ComponentFramework.PropertyTypes.StringProperty;
    button3Tooltip: ComponentFramework.PropertyTypes.StringProperty;
    button3Actions: ComponentFramework.PropertyTypes.StringProperty;
    button4Label: ComponentFramework.PropertyTypes.StringProperty;
    button4Icon: ComponentFramework.PropertyTypes.StringProperty;
    button4Color: ComponentFramework.PropertyTypes.StringProperty;
    button4Tooltip: ComponentFramework.PropertyTypes.StringProperty;
    button4Actions: ComponentFramework.PropertyTypes.StringProperty;
    button5Label: ComponentFramework.PropertyTypes.StringProperty;
    button5Icon: ComponentFramework.PropertyTypes.StringProperty;
    button5Color: ComponentFramework.PropertyTypes.StringProperty;
    button5Tooltip: ComponentFramework.PropertyTypes.StringProperty;
    button5Actions: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    boundField?: any;
}
