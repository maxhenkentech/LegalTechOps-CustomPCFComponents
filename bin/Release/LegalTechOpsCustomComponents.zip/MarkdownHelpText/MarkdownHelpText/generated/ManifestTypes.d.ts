/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    boundText: ComponentFramework.PropertyTypes.StringProperty;
    markdownText: ComponentFramework.PropertyTypes.StringProperty;
    calloutTextLayout: ComponentFramework.PropertyTypes.EnumProperty<"SameLine" | "NewLine">;
    lineSpacing: ComponentFramework.PropertyTypes.DecimalNumberProperty;
}
export interface IOutputs {
    boundText?: string;
}
