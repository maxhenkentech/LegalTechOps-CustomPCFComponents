# CLAUDE.md — RiskMatrix

Scoped guidance for the **RiskMatrix** control only. For repo-wide commands, version management, `pac` deployment, and how to add a new component, see the [main CLAUDE.md](../../CLAUDE.md). This file is gitignored, same as every other `CLAUDE.md` in this repo — see the main file's "Keeping CLAUDE.md files out of git" section.

### RiskMatrix control

- `index.ts` — this is the entire control; it's a `ComponentFramework.StandardControl` implemented with **pure DOM manipulation** (no React/Fluent UI dependency at runtime, only `@fluentui/react-icons` in devDependencies) — a CSS-Grid layout is built and re-built in `createRiskMatrix()`, injecting a single shared `<style id="risk-matrix-styles">` block into `document.head` on first render.
- Grid geometry (rows/cols, spacer tracks, label placement) is computed dynamically in `createRiskMatrix()` based on which optional elements are visible (`ShowCategoryLabels`, `ShowAxisLabels`, `ShowRiskLabel`) and the `GridSize` (2–6). Changing this logic requires updating the column/row track math (`cols`, `rows`, `gridColStart`, `gridRowStart`) consistently — it's index arithmetic, not component composition.
- The risk-level color matrix (which cell gets low/medium/high/critical) is **hardcoded per grid size** in two places that must stay identical: `colorMatrix()` and `getCurrentRiskLevel()`. If you change the risk distribution for a grid size, update both methods.
- `updateView` only calls `createRiskMatrix()` (a full DOM rebuild) when a structural property changed (size, grid size, label visibility); color/marker/tooltip updates on every `updateView` call are cheaper in-place mutations (`colorMatrix`, `updateMarkerPosition`, `updateRiskChipAndTooltip`).
- SVG risk-level icons (success/info/warning/critical) are generated inline as template strings in `getFluentIconSvg` rather than imported components.
