/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    optionsInput: ComponentFramework.PropertyTypes.OptionSetProperty;
    componentHeight: ComponentFramework.PropertyTypes.EnumProperty<"Tall" | "Short">;
    icon: ComponentFramework.PropertyTypes.StringProperty;
    sortBy: ComponentFramework.PropertyTypes.EnumProperty<"Value" | "Text">;
    hideHiddenOptions: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    showColorIcon: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    iconColorOverride: ComponentFramework.PropertyTypes.StringProperty;
    showColorBorder: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    showColorBackground: ComponentFramework.PropertyTypes.EnumProperty<"No" | "Lighter" | "Full">;
    makeFontBold: ComponentFramework.PropertyTypes.TwoOptionsProperty;
}
export interface IOutputs {
    optionsInput?: number;
}
