/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    optionsInput: ComponentFramework.PropertyTypes.OptionSetProperty;
    hideHiddenOptions: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    sortBy: ComponentFramework.PropertyTypes.EnumProperty<"Value" | "Text">;
    placeholderText: ComponentFramework.PropertyTypes.StringProperty;
    componentHeight: ComponentFramework.PropertyTypes.EnumProperty<"Tall" | "Short">;
    selectionShape: ComponentFramework.PropertyTypes.EnumProperty<"Square" | "Rounded" | "Round">;
    makeFontBold: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    useExternalValueForIcon: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    icon: ComponentFramework.PropertyTypes.StringProperty;
    showColorIcon: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    showColorBackground: ComponentFramework.PropertyTypes.EnumProperty<"No" | "Lighter" | "Full">;
    selectionColor: ComponentFramework.PropertyTypes.StringProperty;
    showColorBorder: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    iconColorOverride: ComponentFramework.PropertyTypes.StringProperty;
    hoverColor: ComponentFramework.PropertyTypes.StringProperty;
    listSelectedColor: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    optionsInput?: number;
}
