/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    boundField: ComponentFramework.PropertyTypes.Property;
    source: ComponentFramework.PropertyTypes.EnumProperty<"Audit" | "Activities" | "Notes" | "ActivitiesAndNotes" | "All">;
    activityDate: ComponentFramework.PropertyTypes.EnumProperty<"CreatedOn" | "CompletedOn">;
    aggregation: ComponentFramework.PropertyTypes.EnumProperty<"Day" | "Week" | "Month" | "Year">;
    yearsToShow: ComponentFramework.PropertyTypes.WholeNumberProperty;
    firstDayOfWeek: ComponentFramework.PropertyTypes.EnumProperty<"Monday" | "Tuesday" | "Wednesday" | "Thursday" | "Friday" | "Saturday" | "Sunday" | "Auto">;
    showDetails: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    showSummary: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    showLegend: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    cellShape: ComponentFramework.PropertyTypes.EnumProperty<"Square" | "Rounded" | "Round">;
    colorScheme: ComponentFramework.PropertyTypes.EnumProperty<"Green" | "Blue" | "Purple" | "Orange" | "Red" | "Pink" | "Teal" | "Gray" | "Halloween" | "Heat" | "Ocean" | "Custom">;
    customColor: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    boundField?: any;
}
