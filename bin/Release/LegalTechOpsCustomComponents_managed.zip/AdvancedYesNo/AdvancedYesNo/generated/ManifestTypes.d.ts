/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    value: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    displayStyle: ComponentFramework.PropertyTypes.EnumProperty<"Checkbox" | "Toggle" | "LabeledSwitch" | "Radio" | "Buttons" | "Segmented" | "ToggleButton" | "Chip" | "Icon">;
    showLabels: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    labelPosition: ComponentFramework.PropertyTypes.EnumProperty<"Right" | "Left">;
    optionOrder: ComponentFramework.PropertyTypes.EnumProperty<"YesFirst" | "NoFirst">;
    widthMode: ComponentFramework.PropertyTypes.EnumProperty<"Fill" | "Fixed">;
    fixedWidth: ComponentFramework.PropertyTypes.WholeNumberProperty;
    componentHeight: ComponentFramework.PropertyTypes.EnumProperty<"Tall" | "Short">;
    selectionShape: ComponentFramework.PropertyTypes.EnumProperty<"Square" | "Rounded" | "Round">;
    makeFontBold: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    yesIcon: ComponentFramework.PropertyTypes.StringProperty;
    noIcon: ComponentFramework.PropertyTypes.StringProperty;
    iconPosition: ComponentFramework.PropertyTypes.EnumProperty<"Left" | "Right" | "Above" | "Below">;
    yesColor: ComponentFramework.PropertyTypes.StringProperty;
    noColor: ComponentFramework.PropertyTypes.StringProperty;
    iconColorMode: ComponentFramework.PropertyTypes.EnumProperty<"Auto" | "CustomColor" | "ChoiceColor" | "CustomColorFaded">;
    iconColor: ComponentFramework.PropertyTypes.StringProperty;
    checkedColorMode: ComponentFramework.PropertyTypes.EnumProperty<"CustomColor" | "ChoiceColor" | "CustomColorFaded">;
    checkedColor: ComponentFramework.PropertyTypes.StringProperty;
    selectionBackgroundMode: ComponentFramework.PropertyTypes.EnumProperty<"CustomColor" | "ChoiceColor" | "CustomColorFaded">;
    selectionColor: ComponentFramework.PropertyTypes.StringProperty;
    selectionBorderMode: ComponentFramework.PropertyTypes.EnumProperty<"Off" | "CustomColor" | "ChoiceColor" | "CustomColorFaded">;
    selectionBorderColor: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    value?: boolean;
}
