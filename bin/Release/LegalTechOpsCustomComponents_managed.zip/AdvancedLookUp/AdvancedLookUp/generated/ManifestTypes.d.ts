/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    lookupValue: ComponentFramework.PropertyTypes.LookupProperty;
    searchColumns: ComponentFramework.PropertyTypes.StringProperty;
    sortColumnName: ComponentFramework.PropertyTypes.StringProperty;
    showInactiveRecords: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    resultLimit: ComponentFramework.PropertyTypes.WholeNumberProperty;
    placeholderText: ComponentFramework.PropertyTypes.StringProperty;
    labelColumnName: ComponentFramework.PropertyTypes.StringProperty;
    additionalDisplayColumns: ComponentFramework.PropertyTypes.StringProperty;
    tooltipColumnName: ComponentFramework.PropertyTypes.StringProperty;
    componentHeight: ComponentFramework.PropertyTypes.EnumProperty<"Tall" | "Short">;
    selectionShape: ComponentFramework.PropertyTypes.EnumProperty<"Square" | "Rounded" | "Round">;
    iconColumnName: ComponentFramework.PropertyTypes.StringProperty;
    iconFixedName: ComponentFramework.PropertyTypes.StringProperty;
    iconShape: ComponentFramework.PropertyTypes.EnumProperty<"Full" | "RoundedSquare" | "Circle" | "None">;
    iconBackgroundColor: ComponentFramework.PropertyTypes.StringProperty;
    iconColor: ComponentFramework.PropertyTypes.StringProperty;
    recordBackdropColor: ComponentFramework.PropertyTypes.StringProperty;
    hoverColor: ComponentFramework.PropertyTypes.StringProperty;
    listSelectedColor: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    lookupValue?: ComponentFramework.LookupValue[];
}
