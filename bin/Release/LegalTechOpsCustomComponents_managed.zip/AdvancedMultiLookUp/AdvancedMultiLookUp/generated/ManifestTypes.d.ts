/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    relationshipName: ComponentFramework.PropertyTypes.StringProperty;
    searchColumns: ComponentFramework.PropertyTypes.StringProperty;
    sortColumnName: ComponentFramework.PropertyTypes.StringProperty;
    showInactiveRecords: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    resultLimit: ComponentFramework.PropertyTypes.WholeNumberProperty;
    placeholderText: ComponentFramework.PropertyTypes.StringProperty;
    labelColumnName: ComponentFramework.PropertyTypes.StringProperty;
    additionalDisplayColumns: ComponentFramework.PropertyTypes.StringProperty;
    tooltipColumnName: ComponentFramework.PropertyTypes.StringProperty;
    sortBy: ComponentFramework.PropertyTypes.EnumProperty<"View" | "Text" | "Autofit">;
    selectedDisplayMode: ComponentFramework.PropertyTypes.EnumProperty<"Pills" | "Text">;
    componentHeight: ComponentFramework.PropertyTypes.EnumProperty<"Tall" | "Short">;
    selectionShape: ComponentFramework.PropertyTypes.EnumProperty<"Square" | "Rounded" | "Round">;
    makeFontBold: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    iconColumnName: ComponentFramework.PropertyTypes.StringProperty;
    iconFixedName: ComponentFramework.PropertyTypes.StringProperty;
    iconShape: ComponentFramework.PropertyTypes.EnumProperty<"Full" | "RoundedSquare" | "Circle" | "None">;
    iconBackgroundColor: ComponentFramework.PropertyTypes.StringProperty;
    iconColor: ComponentFramework.PropertyTypes.StringProperty;
    selectionColor: ComponentFramework.PropertyTypes.StringProperty;
    pillBorderMode: ComponentFramework.PropertyTypes.EnumProperty<"Off" | "CustomColor">;
    pillBorderColor: ComponentFramework.PropertyTypes.StringProperty;
    hoverColor: ComponentFramework.PropertyTypes.StringProperty;
    listSelectedColor: ComponentFramework.PropertyTypes.StringProperty;
    records: ComponentFramework.PropertyTypes.DataSet;
}
export interface IOutputs {
}
