/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    optionsInput: ComponentFramework.PropertyTypes.MultiSelectOptionSetProperty;
    hideHiddenOptions: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    sortBy: ComponentFramework.PropertyTypes.EnumProperty<"Value" | "Text" | "Autofit">;
    searchDescriptions: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    placeholderText: ComponentFramework.PropertyTypes.StringProperty;
    selectedDisplayMode: ComponentFramework.PropertyTypes.EnumProperty<"Pills" | "Text">;
    componentHeight: ComponentFramework.PropertyTypes.EnumProperty<"Tall" | "Short">;
    selectionShape: ComponentFramework.PropertyTypes.EnumProperty<"Square" | "Rounded" | "Round">;
    makeFontBold: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    useExternalValueForIcon: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    iconFixedName: ComponentFramework.PropertyTypes.StringProperty;
    iconColorMode: ComponentFramework.PropertyTypes.EnumProperty<"Auto" | "CustomColor" | "ChoiceColor" | "CustomColorFaded">;
    iconColor: ComponentFramework.PropertyTypes.StringProperty;
    selectionBackgroundMode: ComponentFramework.PropertyTypes.EnumProperty<"CustomColor" | "ChoiceColor" | "CustomColorFaded">;
    selectionColor: ComponentFramework.PropertyTypes.StringProperty;
    pillBorderMode: ComponentFramework.PropertyTypes.EnumProperty<"Off" | "CustomColor" | "ChoiceColor" | "CustomColorFaded">;
    pillBorderColor: ComponentFramework.PropertyTypes.StringProperty;
    hoverColor: ComponentFramework.PropertyTypes.StringProperty;
    listSelectedColor: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    optionsInput?: number[];
}
